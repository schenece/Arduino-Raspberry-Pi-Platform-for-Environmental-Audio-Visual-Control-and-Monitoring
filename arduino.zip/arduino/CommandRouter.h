#ifndef COMMAND_ROUTER_H
#define COMMAND_ROUTER_H

namespace CommandRouter {
  void handleSerial();
}

#endif